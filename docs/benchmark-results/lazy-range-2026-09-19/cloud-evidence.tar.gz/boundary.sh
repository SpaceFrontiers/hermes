#!/usr/bin/env bash
set -euo pipefail
source "$HOME/.cargo/env"
cd "$HOME/hermes-lazy-trial/repo"
for attempt in $(seq 1 180); do
  if test -f ../results/status.txt; then break; fi
  sleep 5
done
test "$(cat ../results/status.txt)" = COMPLETE
git restore hermes-core/src/query/range.rs hermes-core/src/structures/fast_field/mod.rs hermes-core/tests/range_bitset.rs
git apply ../candidate-boundary.patch
export CARGO_BUILD_JOBS=8
cargo bench --locked -p hermes-core --bench rust_hot_paths --no-run --message-format=json-render-diagnostics > ../results/build-boundary.jsonl 2> ../results/build-boundary.txt
python3 ../driver.py save-binary boundary
python3 ../boundary.py
