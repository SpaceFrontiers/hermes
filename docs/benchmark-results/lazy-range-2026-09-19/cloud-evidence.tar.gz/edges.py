from pathlib import Path
import subprocess,os,json,hashlib
root=Path.cwd().parent
out=root/'results'/'edges';out.mkdir(exist_ok=True)
env=dict(os.environ,CRITERION_HOME=str(out/'criterion'),RAYON_NUM_THREADS='1')
records=[]
pattern=r'lazy_range/(multi|no_match)/'
for repeat in range(2):
    order=['edge-before','edge-after'] if repeat==0 else ['edge-after','edge-before']
    for stage in order:
        binary=root/f'{stage}-bench'
        command=['taskset','-c','2',str(binary),'--bench','--warm-up-time','1','--measurement-time','2','--save-baseline',f'{stage}-{repeat}',pattern]
        (out/'progress.txt').write_text(f'{stage} repeat {repeat}\n')
        (out/f'{stage}-{repeat}-cpu-before.txt').write_text(Path('/proc/stat').read_text())
        with (out/f'{stage}-{repeat}.txt').open('w') as f:
            subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
        (out/f'{stage}-{repeat}-cpu-after.txt').write_text(Path('/proc/stat').read_text())
        records.append({'stage':stage,'repeat':repeat,'command':command,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
        (out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
(out/'status.txt').write_text('COMPLETE\n')
