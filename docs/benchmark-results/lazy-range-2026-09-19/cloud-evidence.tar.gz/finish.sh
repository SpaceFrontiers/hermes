#!/usr/bin/env bash
set -euo pipefail
export RAYON_NUM_THREADS=1
cd "$HOME/hermes-lazy-trial"
for attempt in $(seq 1 60); do
  if test -f results/edges/status.txt; then break; fi
  sleep 5
done
test "$(cat results/edges/status.txt)" = COMPLETE
for repeat in 0 1 2; do
  stages="edge-before edge-after"
  if test "$repeat" = 1; then stages="edge-after edge-before"; fi
  for stage in $stages; do
    /usr/bin/time -v taskset -c 2 "./$stage-bench" --test lazy_range > "results/edges/$stage-memory-$repeat.txt" 2>&1
  done
done
printf 'COMPLETE\n' > results/final-memory-status.txt
cp "$HOME/setup.sh" setup.sh
tar -xOf baseline.tar.gz hermes-core/benches/rust_hot_paths.rs > benchmark-initial.rs
sha256sum baseline.tar.gz candidate.patch candidate-boundary.patch expanded-bench.rs > results/provenance-sha256.txt
tar --exclude="*/report" --exclude="*/new" --exclude="*/change" -czf evidence.tar.gz results driver.py boundary.py edges.py setup.sh boundary.sh edges.sh finish.sh candidate.patch candidate-boundary.patch benchmark-initial.rs expanded-bench.rs
sha256sum evidence.tar.gz
