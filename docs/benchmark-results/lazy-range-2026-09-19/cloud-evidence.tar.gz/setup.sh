#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
sudo systemctl stop apt-daily.timer apt-daily-upgrade.timer unattended-upgrades.service || true
sudo apt-get update
sudo env DEBIAN_FRONTEND=noninteractive apt-get install -y build-essential pkg-config libssl-dev protobuf-compiler git curl python3 time
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs -o rustup.sh
sh rustup.sh -y --profile minimal --default-toolchain 1.98.1
source "$HOME/.cargo/env"
rustup component add rustfmt clippy --toolchain 1.98.1
mkdir -p hermes-lazy-trial/repo hermes-lazy-trial/results
cp baseline.tar.gz candidate.patch driver.py hermes-lazy-trial/
tar -xzf baseline.tar.gz -C hermes-lazy-trial/repo
cd hermes-lazy-trial/repo
git init -b benchmark
git -c user.name=Benchmark -c user.email=benchmark@localhost add .
git -c user.name=Benchmark -c user.email=benchmark@localhost commit -qm 'Benchmark source snapshot'
export CARGO_BUILD_JOBS=8
export CARGO_PROFILE_TEST_DEBUG=0
export CARGO_PROFILE_DEV_DEBUG=0
cargo bench --locked -p hermes-core --bench rust_hot_paths --no-run --message-format=json-render-diagnostics > ../results/build-before.jsonl 2> ../results/build-before.txt
python3 ../driver.py save-binary before
git apply ../candidate.patch
cargo test --locked -p hermes-core --lib structures::fast_field::tests -- --test-threads=2 > ../results/codec-tests.txt 2>&1
cargo test --locked -p hermes-core --test range_bitset -- --test-threads=2 > ../results/range-tests.txt 2>&1
cargo bench --locked -p hermes-core --bench rust_hot_paths --no-run --message-format=json-render-diagnostics > ../results/build-after.jsonl 2> ../results/build-after.txt
python3 ../driver.py save-binary after
python3 ../driver.py measure
printf 'COMPLETE\n' > ../results/status.txt
