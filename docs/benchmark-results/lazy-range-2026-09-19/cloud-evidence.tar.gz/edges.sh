#!/usr/bin/env bash
set -euo pipefail
source "$HOME/.cargo/env"
cd "$HOME/hermes-lazy-trial/repo"
for attempt in $(seq 1 240); do
  if test -f ../results/boundary/status.txt; then break; fi
  sleep 5
done
test "$(cat ../results/boundary/status.txt)" = COMPLETE
cp ../expanded-bench.rs hermes-core/benches/rust_hot_paths.rs
export CARGO_BUILD_JOBS=8 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0
cargo test --locked -p hermes-core --test range_bitset > ../results/final-range-tests.txt 2>&1
cargo bench --locked -p hermes-core --bench rust_hot_paths --no-run --message-format=json-render-diagnostics > ../results/build-edge-after.jsonl 2> ../results/build-edge-after.txt
python3 ../driver.py save-binary edge-after
git restore hermes-core/src/query/range.rs hermes-core/src/structures/fast_field/mod.rs
cargo bench --locked -p hermes-core --bench rust_hot_paths --no-run --message-format=json-render-diagnostics > ../results/build-edge-before.jsonl 2> ../results/build-edge-before.txt
python3 ../driver.py save-binary edge-before
python3 ../edges.py
