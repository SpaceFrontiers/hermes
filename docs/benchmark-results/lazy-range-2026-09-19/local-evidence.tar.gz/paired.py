from pathlib import Path
import os,subprocess,json,shutil,hashlib
root=Path(__file__).resolve().parent
artifacts=[json.loads(s) for s in (root/'build-after.jsonl').read_text().splitlines()]
paths=[a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='rust_hot_paths' and a.get('executable')]
assert len(paths)==1
shutil.copy2(paths[0],root/'after-bench')
env=dict(os.environ,CRITERION_HOME=str(root/'criterion'),RAYON_NUM_THREADS='1')
runs=[]
for repeat in range(2):
    for stage in (['before','after'] if repeat==0 else ['after','before']):
        binary=root/f'{stage}-bench'
        cmd=[str(binary),'--bench','--warm-up-time','1','--measurement-time','2','--save-baseline',f'{stage}-{repeat}',r'lazy_range|range_bitset/production|range_scan_layouts/bucketed/65536/16_blocks$']
        print(stage,repeat,flush=True)
        with (root/f'{stage}-{repeat}.txt').open('w') as out:
            subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
        runs.append({'stage':stage,'repeat':repeat,'command':cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
        (root/'runs.json').write_text(json.dumps(runs,indent=2)+'\n')
for repeat in range(3):
    for stage in (['before','after'] if repeat%2==0 else ['after','before']):
        with (root/f'{stage}-memory-{repeat}.txt').open('w') as out:
            subprocess.run(['/usr/bin/time','-l',str(root/f'{stage}-bench'),'--test','lazy_range'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
