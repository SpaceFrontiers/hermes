from pathlib import Path
import subprocess, json, os, sys, shutil, hashlib
root=Path.cwd().parent
out=root/'results'
if sys.argv[1]=='save-binary':
    stage=sys.argv[2]
    artifacts=[json.loads(line) for line in (out/f'build-{stage}.jsonl').read_text().splitlines()]
    paths=[a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='rust_hot_paths' and a.get('executable')]
    assert len(paths)==1, paths
    shutil.copyfile(paths[0],root/f'{stage}-bench')
    (root/f'{stage}-bench').chmod(0o755)
    sys.exit(0)
assert sys.argv[1]=='measure'
env=dict(os.environ,CRITERION_HOME=str(out/'criterion'),RAYON_NUM_THREADS='1')
metadata={'lscpu':json.loads(subprocess.check_output(['lscpu','-J'],text=True)),'rustc':subprocess.check_output(['rustc','-Vv'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True),'affinity_cpu':2,'package_version':'1.8.146','RUSTFLAGS':os.environ.get('RUSTFLAGS',''),'RAYON_NUM_THREADS':'1','baseline_archive_sha256':hashlib.sha256((root/'baseline.tar.gz').read_bytes()).hexdigest(),'candidate_patch_sha256':hashlib.sha256((root/'candidate.patch').read_bytes()).hexdigest(),'binaries':{stage:hashlib.sha256((root/f'{stage}-bench').read_bytes()).hexdigest() for stage in ['before','after']},'commands':[]}
metadata['kernel']=subprocess.check_output(['uname','-sr'],text=True)
metadata['cpu_siblings']=Path('/sys/devices/system/cpu/cpu2/topology/thread_siblings_list').read_text().strip()
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
pattern=r'range_scan_layouts|range_bitset/production'
for repeat in range(2):
    order=['before','after'] if repeat==0 else ['after','before']
    for stage in order:
        command=['taskset','-c','2',str(root/f'{stage}-bench'),'--bench','--warm-up-time','2','--measurement-time','4','--sample-size','30','--save-baseline',f'cloud-{stage}-{repeat}',pattern]
        metadata['commands'].append(command)
        (out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
        (out/'progress.txt').write_text(f'{stage} repeat {repeat}\n')
        (out/f'{stage}-{repeat}-cpu-before.txt').write_text(Path('/proc/stat').read_text())
        with (out/f'{stage}-{repeat}.txt').open('w') as f:
            subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
        (out/f'{stage}-{repeat}-cpu-after.txt').write_text(Path('/proc/stat').read_text())
for repeat in range(3):
    order=['before','after'] if repeat%2==0 else ['after','before']
    for stage in order:
        with (out/f'{stage}-memory-{repeat}.txt').open('w') as f:
            subprocess.run(['/usr/bin/time','-v','taskset','-c','2',str(root/f'{stage}-bench'),'--test',pattern],stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
(out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
